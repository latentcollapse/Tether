# HLX Bootstrap Capsule (HBC) v1.0

This package contains the complete, self-contained definition of the HLX Language Family.
Upload this entire folder (or zip) to an LLM to bootstrap it with HLX capabilities.

## Contents

* **SYSTEM_PROMPT.txt**: The primary directive for LLM alignment.
* **hlx_codex.json**: The formal specification (Grammar, Semantics, Values).
* **hlx_runtime_conformance.json**: The rules of the runtime engine.
* **hlx_triggers.yaml**: Canonical mode switches (HPCP).
* **hlx_examples.hlx(l)**: Rosetta stone examples.

## Cold LLM Bootstrap Guarantee

Uploading this capsule alone is sufficient to initialize a compliant HLX node.
* No prior HLX knowledge required.
* No execution required (knowledge-only).
* Runtime authority is external (do not hallucinate execution).
* LC streams must never be hallucinated.

## Usage

1. Upload this zip to the LLM.
2. Tell the LLM: "Initialize from the HLX Bootstrap Capsule."
3. The LLM is now HLX-Native.