"""Tether relay server package."""
